# jsquiz
This repository is for developing simple javascript quiz portal for demo
